
This folder contains the simulated data used in paper:
Y. Huang and S. Kleinberg. Fast and Accurate Causal Inference from Time Series Data. FLAIRS 2015.

Specifically, there are two kinds of datasets: common cause and effect datasets and random datasets. Each kind of datasets includes two folders, namely causal-str (with files describing the causal structures) and time-series (with the time series data).

Note that there are six columns in each causal structure file: cause, effect, start, end, impact, and probability, where:
cause and effect are the cause and effect of a relationship;
start and end are the start and end of the time window of a relationship (e.g. 1 and 3 in window [1, 3]);
impact is the causal impact (say insulin decreases blood glucose by 100 mg/dL, then the causal impact of insulin on blood glucose is 100 mg/dL);
probability is the probability of the cause yielding the effect (so 1 indicates deterministic relationship).

The following is a brief description of the two kinds of datasets. Please see details of the data generation process in the FLAIRS paper (section Experimental results).

Simulated common cause and effect datasets:
We generated two datasets with common cause (where variable 0 causing 1 to 3) and common effect (where variables 0 and 1 causing 2 and 3) structures. The data consist of 20 variables (16 of them are noise) and 1000 timepoints. An effect's value at each time is the sum of the impact of its causes that occurred previously. The time window of all relationships was set as [1, 3], and the impact of each cause was set as +5 or -5. The value of variables with no causes were randomly set to zero or one at each time.

Simulated random datasets:
We generated 20 datasets each with a different random causal structure. The data include 20 variables and 1000 timepoints. The differences from the previous dataset are: 1) causality here is probabilistic, with the probability of each cause yielding its effects as 0.5; 2) r = s and was randomly chosen in [1, 3]. The mean number (across the 20 datasets) of relationships in each dataset is 41.8, with standard deviation of 4.905.

